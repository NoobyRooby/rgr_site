from flask import Flask, render_template, request, redirect, url_for, json, jsonify, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import random
import string
import time
import os
import warnings
from flask_mail import Mail, Message
from sqlalchemy.exc import IntegrityError
from datetime import date, time, datetime, timedelta
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import logging
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from flask_migrate import Migrate
from captcha.image import ImageCaptcha
import base64
from flask import send_file


pdfmetrics.registerFont(TTFont('TimesNewRoman', 'Times New Roman.ttf'))
print(f"Current date: {date.today().isoformat()}")
print(f"Current datetime: {datetime.now().isoformat()}")
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
PROFILE_DATABASE_PATH = os.path.join(BASE_DIR, 'instance', 'events.db')

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///events.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['MAIL_SERVER'] = 'smtp.googlemail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'gmgliana@gmail.com'
app.config['MAIL_DEFAULT_SENDER'] = 'gmgliana@gmail.com'
app.config['MAIL_PASSWORD'] = 'rkut cglh sptw zhkm'


db = SQLAlchemy(app)
migrate = Migrate(app,  db)
mail = Mail(app)

logging.basicConfig(level=logging.DEBUG)

# Словарь для хранения кодов подтверждения и времени их отправки
confirmation_codes = {}

def get_db_connection(database):
    conn = sqlite3.connect(database)
    conn.row_factory = sqlite3.Row
    return conn


def generate_rsa_keys():
    key = RSA.generate(2048)
    private_key = key.export_key()
    public_key = key.publickey().export_key()
    return private_key, public_key


def load_rsa_keys():
    # Load existing keys or generate new ones if they don't exist
    try:
        with open('private.pem', 'rb') as f:
            private_key = f.read()
        with open('public.pem', 'rb') as f:
            public_key = f.read()
    except FileNotFoundError:
        private_key, public_key = generate_rsa_keys()
        with open('private.pem', 'wb') as f:
            f.write(private_key)
        with open('public.pem', 'wb') as f:
            f.write(public_key)
    return private_key, public_key


private_key, public_key = load_rsa_keys()


def rsa_encrypt(data):
    recipient_key = RSA.import_key(public_key)
    cipher_rsa = PKCS1_OAEP.new(recipient_key)
    encrypted_data = cipher_rsa.encrypt(data.encode())
    return base64.b64encode(encrypted_data).decode()


def rsa_decrypt(encrypted_data):
    key = RSA.import_key(private_key)
    cipher_rsa = PKCS1_OAEP.new(key)
    decrypted_data = cipher_rsa.decrypt(base64.b64decode(encrypted_data)).decode()
    return decrypted_data


def generate_captcha_text(length=6):
    digits = '0123456789'
    return ''.join(random.choice(digits) for i in range(length))


def generate_and_save_confirmation_code(email):
    confirmation_code = generate_confirmation_code()
    session['confirmation_code'] = confirmation_code
    session['confirmation_code_timestamp'] = time.time()
    session['user_email'] = email
    return confirmation_code


@app.route('/captcha')
def captcha():
    captcha_text = generate_captcha_text()
    session['captcha_text'] = captcha_text
    logging.info(f'Captcha text in session: {captcha_text}')
    image = ImageCaptcha()
    data = image.generate(captcha_text)
    return send_file(data, mimetype='image/png')


class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.Text(100), nullable=False)
    genre_id = db.Column(db.Integer, db.ForeignKey('genre.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    time = db.Column(db.Time, nullable=False)
    location_id = db.Column(db.Integer, db.ForeignKey('location.id'), nullable=False)
    description = db.Column(db.Text, nullable=False)
    image = db.Column(db.Text(1000), nullable=False)
    available_seats = db.Column(db.JSON, nullable=False)
    price = db.Column(db.Integer, nullable=False)

    genre = db.relationship('Genre', backref='events')
    location = db.relationship('Location', backref='events')


    def __repr__(self):
        return f"Event(id={self.id}, title='{self.title}', genre_id={self.genre_id}, location_id={self.location_id})"


class Users(db.Model):
    name = db.Column(db.Text(30), nullable=False)
    surname = db.Column(db.Text(30), nullable=False)
    email = db.Column(db.Text(100), unique=True, nullable=False,primary_key=True)
    password = db.Column(db.Text(20), nullable=False)
    passport_number = db.Column(db.Text(1000), unique=True, nullable=False)# Encrypted passport number
    passport_issue_date = db.Column(db.Date, nullable=False)

    def __init__(self,  name, surname, email, password, passport_number, passport_issue_date):
        self.name = name
        self.surname = surname
        self.email = email
        self.password = password
        self.passport_number = passport_number
        self.passport_issue_date = passport_issue_date

    def __repr__(self):
        return f"Users( name='{self.name}', email='{self.email}')"
    def check_password(self, password):
        return check_password_hash(self.password, password)


class Genre(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(20), nullable=False)

    def __repr__(self):
        return f"Genre(id={self.id}, type='{self.type}')"


class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    place = db.Column(db.Text(100), nullable=False)
    address = db.Column(db.Text(100), nullable=False)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)

    def __repr__(self):
        return f"Location(id={self.id}, place='{self.place}', address='{self.address}')"


class Ticket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.Text(50), nullable=False)
    user_surname = db.Column(db.Text(50), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.email'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    event_title = db.Column(db.String(100), nullable=False)
    location_id = db.Column(db.Integer, db.ForeignKey('location.id'), nullable=False)
    location_place = db.Column(db.String(100), nullable=False)
    location_address = db.Column(db.String(100), nullable=False)
    seat = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    date = db.Column(db.Date, nullable=False)
    time = db.Column(db.Time, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)

    user = db.relationship('Users', backref='tickets')
    event = db.relationship('Event', backref='tickets')

    def __repr__(self):
        return f"Ticket(id={self.id}, user_name='{self.user_name}', user_surname='{self.user_surname}', user_id='{self.user_id}', event_id='{self.event_id}', event_title='{self.event_title}', location_place='{self.location_place}', location_address='{self.location_address}', seat_number={self.seat_number}, price={self.price}, event_date='{self.event_date}', event_time='{self.event_time}', created_at='{self.created_at}')"


class FavoriteEvent(db.Model):
    __tablename__ = 'favorite_events'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Text(100), db.ForeignKey('users.email'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)

    user = db.relationship('Users', backref='favorite_events')
    event = db.relationship('Event', backref='favorite_events')

    def __repr__(self):
        return f"FavoriteEvent(id={self.id}, user_id='{self.user_id}', event_id={self.event_id})"

    @classmethod
    def add_to_favorites(cls, user_id, event_id):
        favorite = cls(user_id=user_id, event_id=event_id)
        db.session.add(favorite)
        db.session.commit()
        return favorite

    @classmethod
    def remove_from_favorites(cls, user_id, event_id):
        favorite = cls.query.filter_by(user_id=user_id, event_id=event_id).first()
        if favorite:
            db.session.delete(favorite)
            db.session.commit()

    @classmethod
    def get_user_favorites(cls, user_id):
        return cls.query.filter_by(user_id=user_id).all()

def create_event_table():
    conn = get_db_connection('events.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS event
                 (id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                genre_id INTEGER NOT NULL,
                date DATE NOT NULL,
                time TIME NOT NULL,
                location_id INTEGER NOT NULL,
                description TEXT NOT NULL,
                image TEXT NOT NULL,
                available_seats TEXT(1000) NOT NULL,
                price INTEGER NOT NULL)''')
    conn.commit()
    conn.close()


def create_location_table():
    conn = get_db_connection('events.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS location
                 (id INTEGER PRIMARY KEY,
                place TEXT(100) NOT NULL,
                address TEXT(100) NOT NULL)''')
    conn.commit()
    conn.close()

def create_table_favorite_events ():
    conn = get_db_connection('events.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS favorite_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    event_id INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(email),
    FOREIGN KEY (event_id) REFERENCES event(id)
    )''')
    conn.commit()
    conn.close()

def create_ticket_table():
    conn = get_db_connection('events.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS ticket
                (id INTEGER PRIMARY KEY,
                user_name TEXT(50) NOT NULL,
                user_surname TEXT(50) NOT NULL,
                user_id INTEGER NOT NULL,
                event_title TEXT(50) NOT NULL,
                event_id INTEGER NOT NULL,
                date DATE NOT NULL,
                time TIME NOT NULL,
                location_id INTEGER NOT NULL,
                location_place TEXT(100) NOT NULL,
                location_address TEXT(100) NOT NULL,
                seat INTEGER NOT NULL,
                price INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )''')

    conn.commit()
    conn.close()

def create_users_table():
    conn = get_db_connection('events.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                (
                 name TEXT(30) NOT NULL,
                 surname TEXT(30) NOT NULL,
                 email TEXT(100) UNIQUE NOT NULL PRIMARY KEY,
                 password TEXT(20) NOT NULL,
                 passport_number TEXT(1000) UNIQUE NOT NULL,
                 passport_issue_date DATE NOT NULL
                )''')
    conn.commit()
    conn.close()

    
def create_genre_table():
    conn = get_db_connection('events.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS genre
                     (id INTEGER PRIMARY KEY,
                    type TEXT(30) NOT NULL)''')
    conn.commit()
    conn.close()


@app.route('/')
@app.route('/home')
@app.route('/events/<string:genre>')
def index(genre=None):
    conn = get_db_connection('events.db')
    c = conn.cursor()

    if genre:
        c.execute('''
            SELECT event.id, event.title, event.genre_id, event.date, event.time, 
                   location.place, event.description, event.image, event.available_seats, event.price 
            FROM event
            JOIN location ON event.location_id = location.id
            JOIN genre ON event.genre_id = genre.id
            WHERE genre.type = ? AND event.date >= ?
            ORDER BY event.date ASC, event.time ASC
        ''', (genre, datetime.now().date().isoformat()))
    else:
        c.execute('''
            SELECT event.id, event.title, event.genre_id, event.date, event.time, 
                   location.place, event.description, event.image, event.available_seats, event.price 
            FROM event
            JOIN location ON event.location_id = location.id
            WHERE event.date >= ?
            ORDER BY event.date ASC, event.time ASC
        ''', (datetime.now().date().isoformat(),))

    events = c.fetchall()
    event_data = []
    for event in events:
        formatted_date = datetime.strptime(event[3], '%Y-%m-%d').strftime('%d-%m-%Y')
        formatted_time = datetime.strptime(event[4], '%H:%M:%S').strftime('%H:%M')
        event_data.append({
            'id': event[0],
            'title': event[1],
            'genre_id': event[2],
            'date': formatted_date,
            'time': formatted_time,
            'location': event[5],
            'description': event[6],
            'image': event[7],
            'available_seats': event[8],
            'price': event[9]
        })

    # Get the two closest events
    upcoming_events = event_data[:2]

    is_logged_in = 'user_email' in session
    if is_logged_in:
        user_email = session['user_email']
        user = Users.query.filter_by(email=user_email).first()
        conn.commit()
        conn.close()
        return render_template("index.html", events=event_data, is_logged_in=is_logged_in, users=user,
                               upcoming_events=upcoming_events, genre=genre)

    else:
        return render_template("index.html", events=event_data, is_logged_in=is_logged_in, users=None,
                               upcoming_events=upcoming_events, genre=genre)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = Users.query.filter_by(email=email).first()

        if user and user.check_password(password):
            session['user_email'] = email
            session['email'] = email
            # Генерируем код подтверждения
            code = generate_confirmation_code()
            session['code'] = code
            confirmation_codes[email] = {
                'code': code,
                'sent_at': datetime.now()
            }
            # Отправляем код подтверждения на email
            send_confirmation_email_log(user.email, code)

            # Логирование успешного входа пользователя
            logging.info('Пользователь успешно вошел в систему')
            return jsonify({'success': True, 'redirect_to': url_for('confirm_code'), 'email': user.email})
        else:
            return jsonify({'success': False, 'message': 'Неправильный email или пароль'})

    # Рендерим HTML-страницу авторизации
    return render_template('login.html')


@app.route('/confirm_code', methods=['GET', 'POST'])
def confirm_code():
    if request.method == 'POST':
        email = session.get('user_email')
        if not email:
            return jsonify({'success': False, 'message': 'Email не был найден в сессии'})

        code = request.form['code']

        if email in confirmation_codes and confirmation_codes[email]['code'] == code and \
                datetime.now() - confirmation_codes[email]['sent_at'] < timedelta(minutes=10):
            del confirmation_codes[email]
            session['is_logged_in'] = True
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Invalid verification code or code expired'})

    return render_template('confirm_code.html')


@app.route('/logout')
def logout():
    if 'user_email' in session:
        session.pop('user_email', None)
    return redirect(url_for('index'))


# Генерация кода подтверждения
def generate_confirmation_code():
    return ''.join(random.choices(string.digits, k=6))


def send_confirmation_email_log(email, confirmation_code):
    msg = Message('Код подтверждения входа в систему:',
                  sender=app.config['MAIL_DEFAULT_SENDER'],
                  recipients=[email])
    msg.body = f'Ваш код подтверждения: {confirmation_code}'
    mail.send(msg)

def send_confirmation_email(email, confirmation_code):
    msg = Message('Код подтверждения для регистрации',
                  sender=app.config['MAIL_DEFAULT_SENDER'],
                  recipients=[email])
    msg.body = f'Ваш код подтверждения: {confirmation_code}'
    mail.send(msg)


@app.route('/registration', methods=['GET', 'POST'])
def registration():
    errors = {}
    if request.method == 'POST':
        name = request.form.get('name')
        surname = request.form.get('surname')
        email = request.form.get('email')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')
        passport_number = request.form.get('passport_number')
        passport_date = request.form.get('passport_date')

        try:
            passport_issue_date = date.fromisoformat(passport_date)
        except ValueError:
            errors['passport_date'] = 'Пожалуйста, введите корректную дату выдачи паспорта в формате ГГГГ-ММ-ДД.'

        # Проверка на обязательные поля
        if not name:
            errors['name'] = 'Пожалуйста, введите ваше имя.'
        if not surname:
            errors['surname'] = 'Пожалуйста, введите вашу фамилию.'
        if not email:
            errors['email'] = 'Пожалуйста, введите ваш email.'
        if not password1:
            errors['password1'] = 'Пожалуйста, введите пароль.'
        elif len(password1) < 5:
            errors['password1'] = 'Пароль должен содержать не менее 5 символов.'
        elif not password1.isalnum():
            errors['password1'] = 'Пароль должен содержать только латинские буквы и цифры.'
        if not password2:
            errors['password2'] = 'Пожалуйста, повторите пароль.'
        if password1 != password2:
            errors['password2'] = 'Пароли не совпадают.'
        if not passport_number:
            errors['passport_number'] = 'Пожалуйста, введите номер паспорта.'
        elif len(passport_number) != 10:
            errors['passport_number'] = 'Номер паспорта должен содержать 10 символов.'
        elif not passport_number.isdigit():
            errors['passport_number'] = 'Номер паспорта должен содержать только цифры.'
        if not passport_date:
            errors['passport_date'] = 'Пожалуйста, введите дату выдачи паспорта.'

        # Проверка уникальности email и паспортного номера
        existing_user = Users.query.filter_by(email=email).first()
        if existing_user:
            errors['email'] = 'Пользователь с таким email уже существует'
            return render_template('registration.html', errors=errors)

        existing_passport = Users.query.filter_by(passport_number=passport_number).first()
        if existing_passport:
            errors['passport_number'] = 'Пользователь с таким номером паспорта уже существует'
            return render_template('registration.html', errors=errors)

        if errors:
            return render_template('registration.html', errors=errors)

        # Генерация кода подтверждения и отправка письма
        confirmation_code = generate_confirmation_code()
        send_confirmation_email(email, confirmation_code)

        # Шифрование пароля и паспортного номера
        hashed_password = generate_password_hash(password1)
        encrypted_passport_number = rsa_encrypt(passport_number)

        # Сохранение данных пользователя в сессии
        session['new_user'] = {
            'name': name,
            'surname': surname,
            'email': email,
            'password': hashed_password,
            'passport_number': encrypted_passport_number,
            'passport_issue_date': passport_issue_date,
            'confirmation_code': confirmation_code
        }

        return redirect(url_for('confirm_registration', email=email))
    else:
        return render_template('registration.html')


@app.route('/confirm_registration', methods=['GET', 'POST'])
def confirm_registration():
    email = request.args.get('email')
    if request.method == 'POST':
        confirmation_code = request.form.get('confirmation_code')
        new_user_data = session.pop('new_user', None)
        if new_user_data and new_user_data['confirmation_code'] == confirmation_code:
            new_user = Users(
                name=new_user_data['name'],
                surname=new_user_data['surname'],
                email=new_user_data['email'],
                password=new_user_data['password'],
                passport_number=new_user_data['passport_number'],
                passport_issue_date=datetime.strptime(new_user_data['passport_issue_date'], '%a, %d %b %Y %H:%M:%S GMT').date()
            )
            try:
                db.session.add(new_user)
                db.session.commit()
                logging.info(f'Пользователь {email} успешно зарегистрирован')
                return redirect(url_for('login'))
            except IntegrityError as e:
                db.session.rollback()
                logging.error(f'Error saving user: {e}')
                errors = {'message': 'Произошла ошибка при сохранении пользователя. Попробуйте еще раз.'}
                return render_template('confirm_registration.html', errors=errors)
        else:
            errors = {'confirmation_code': 'Неверный код подтверждения'}
            return render_template('confirm_registration.html', errors=errors)
    return render_template('confirm_registration.html', email=email)


@app.route('/event/<int:event_id>', methods=['GET', 'POST'])
def event(event_id):
    with get_db_connection('events.db') as conn:
        c = conn.cursor()
        c.execute('''
            SELECT event.id, event.title, event.genre_id, event.date, event.time, 
                   location.place,  location.address, location.latitude, location.longitude, event.description, event.image, event.available_seats, event.price 
            FROM event
            JOIN location ON event.location_id = location.id
            WHERE event.id=?
        ''', (event_id,))
        event = c.fetchone()

        if event:
            formatted_date = datetime.strptime(event[3], '%Y-%m-%d').strftime('%d-%m-%Y')
            formatted_time = datetime.strptime(event[4], '%H:%M:%S').strftime('%H:%M')
            location_address = event[6]
            event_data = {
                'id': event[0],
                'title': event[1],
                'genre_id': event[2],
                'date': formatted_date,
                'time': formatted_time,
                'location_place': event[5],
                'location_address': event[6],
                'latitude': event[7],
                'longitude': event[8],
                'description': event[9],
                'image': event[10],
                'available_seats': event[11],
                'price': event[12]
            }

            if request.method == 'POST':
                if 'user_email' in session:
                    return redirect("available_seats", )
                else:
                    return redirect(url_for('login'))

            return render_template("event.html", event=event_data)
        else:
            return "Event not found", 404


@app.route('/profile/<user_email>')
def profile(user_email):
    # Проверяем, авторизован ли пользователь
    if 'user_email' in session:
        # Проверяем, совпадает ли email пользователя с email в сессии
        if session['user_email'] == user_email:

            # Получение данных профиля из PROFILE_DATABASE_PATH
            with get_db_connection(PROFILE_DATABASE_PATH) as conn:
                c = conn.cursor()
                c.execute("SELECT name, surname, email, password, passport_number, passport_issue_date FROM users WHERE email = ?", (user_email,))
                user_data = c.fetchone()

            if user_data:
                user = {
                    'name': user_data[0],
                    'surname': user_data[1],
                    'email': user_data[2],
                    'password': user_data[3],
                    'passport_number': user_data[4],
                    'passport_issue_date': user_data[5]
                }

                # Получаем избранные мероприятия пользователя
                favorite_events = get_favorite_events(user_email)
                # Рендерим шаблон профиля с данными пользователя и его билетами
                return render_template('profile.html', user=user, favorite_events=favorite_events)
            else:
                return "Пользователь не найден", 404
        else:
            return "Вы не авторизованы для просмотра этого профиля", 403
    else:
        # Если пользователь не авторизован, перенаправляем его на страницу входа
        return redirect(url_for('login'))

def get_favorite_events(user_email):
    with get_db_connection('events.db') as conn:
        c = conn.cursor()
        app.logger.debug("Выполняем SQL-запрос для получения избранных мероприятий пользователя")
        c.execute("""
            SELECT 
                e.id, 
                e.title, 
                e.date, 
                e.time, 
                l.place, 
                l.address
            FROM favorite_events fe
            JOIN event e ON fe.event_id = e.id
            JOIN location l ON e.location_id = l.id
            WHERE fe.user_id = ?
        """, (user_email,))
        favorites = c.fetchall()

    favorites_list = []
    for row in favorites:
        favorite = {
            'id': row[0],
            'title': row[1],
            'date': datetime.strptime(row[2], '%Y-%m-%d').strftime('%d-%m-%Y'),
            'time': datetime.strptime(row[3], '%H:%M:%S').strftime('%H:%M'),
            'location_place': row[4],
            'location_address': row[5]
        }
        favorites_list.append(favorite)

    return favorites_list


@app.route('/toggle_favorite/<int:event_id>', methods=['POST'])
def toggle_favorite(event_id):
    # Проверяем, авторизован ли пользователь
    if 'user_email' in session:
        user_email = session['user_email']

        with get_db_connection('events.db') as conn:
            c = conn.cursor()

            # Проверяем, есть ли запись в таблице favorite_events
            c.execute("SELECT * FROM favorite_events WHERE user_id = ? AND event_id = ?", (user_email, event_id))
            favorite = c.fetchone()

            if favorite:
                # Если запись есть, удаляем ее
                c.execute("DELETE FROM favorite_events WHERE user_id = ? AND event_id = ?", (user_email, event_id))
                is_favorite = False
            else:
                # Если записи нет, добавляем ее
                c.execute("INSERT INTO favorite_events (user_id, event_id) VALUES (?, ?)", (user_email, event_id))
                is_favorite = True

            conn.commit()

        # Возвращаем ответ с флагом, указывающим, добавлено ли мероприятие в избранное
        return jsonify({'success': True, 'is_favorite': is_favorite})
    else:
        # Если пользователь не авторизован, возвращаем ошибку
        return jsonify({'success': False, 'error': 'Вы должны быть авторизованы'}), 403



@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    if request.method == 'POST':
        captcha_text = request.form['captcha']
        if captcha_text != session['captcha_text']:
            flash('Неправильный код капчи', 'danger')
            return render_template('change_password.html')

        email = session['user_email']
        old_password = request.form['old_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        user = Users.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, old_password):
            if new_password == confirm_password:
                hashed_password = generate_password_hash(new_password)
                user.password = hashed_password
                db.session.commit()
                logging.info(f'Пользователь {email} успешно изменил пароль')
                return redirect(url_for('profile', user_email=email))
            else:
                flash('Новые пароли не совпадают', 'danger')
        else:
            flash('Неправильный старый пароль', 'danger')

    return render_template('change_password.html')


@app.route('/remember', methods=['GET', 'POST'])
def remember():
    if request.method == 'POST':
        email = request.form['email']
        user = Users.query.filter_by(email=email).first()
        if user:
            # Генерация кода подтверждения и отправка письма
            confirmation_code = generate_confirmation_code()
            send_reset_password_email(email, confirmation_code)

            # Сохранение кода подтверждения в сессии
            session['reset_password_email'] = email
            session['reset_password_code'] = confirmation_code

            return redirect(url_for('reset_password_no'))
        else:
            flash('Пользователь с таким email-ом не найден', 'danger')
    return render_template("remember.html")


@app.route('/reset_password_no', methods=['GET', 'POST'])
def reset_password_no():
    email = session.get('reset_password_email')
    if not email:
        return redirect(url_for('remember'))

    if request.method == 'POST':
        confirmation_code = request.form.get('confirmation_code')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        if confirmation_code != session['reset_password_code']:
            flash('Неверный код подтверждения', 'danger')
            return render_template('reset_password_no.html', email=email)

        if not password1 or not password2:
            flash('Пожалуйста, введите новый пароль', 'danger')
            return render_template('reset_password_no.html', email=email)

        if password1 != password2:
            flash('Пароли не совпадают', 'danger')
            return render_template('reset_password_no.html', email=email)

        user = Users.query.filter_by(email=email).first()
        user.password = generate_password_hash(password1)
        db.session.commit()

        # Очистка данных из сессии
        session.pop('reset_password_email', None)
        session.pop('reset_password_code', None)

        flash('Пароль успешно изменен', 'success')
        return redirect(url_for('login'))

    return render_template('reset_password_no.html', email=email)


def send_reset_password_email(email, confirmation_code):
    msg = Message('Код для сброса пароля',
                  sender=app.config['MAIL_DEFAULT_SENDER'],
                  recipients=[email])
    msg.body = f'Ваш код для сброса пароля: {confirmation_code}'
    mail.send(msg)


@app.route('/reset_password/<email>', methods=['GET', 'POST'])
def reset_password(email):
    if request.method == 'POST':
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        user = Users.query.filter_by(email=email).first()

        if new_password == confirm_password:
            hashed_password = generate_password_hash(new_password)
            user.password = hashed_password
            db.session.commit()
            return redirect(url_for('login'))
        else:
            flash('Новые пароли не совпадают', 'danger')
    return render_template("reset_password.html", email=email)



@app.route('/agreement')
def agreement():
    return render_template("agreement.html")


if __name__ == '__main__':
    with app.app_context():
        create_event_table()
        create_location_table()
        create_genre_table()
        create_users_table()
        create_ticket_table()
        create_table_favorite_events()
        db.create_all()
    app.run(debug=True)


